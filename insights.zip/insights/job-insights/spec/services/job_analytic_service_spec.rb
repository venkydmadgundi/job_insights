require 'rails_helper'

describe JobAnalyticService do
  let(:industry) { Industry.find_or_create_by!(name: "Information Technology") }

  let!(:high_ctr_jobs) do
    3.times.map do |counter|
      job = Job.create!(title: "High CTR#{counter}", description: "Good", industry: industry, clicks: 10)
      JobView.create!(job: job, created_at: 2.days.ago)
      job
    end
  end

  let!(:low_ctr_job) do
    job = Job.create!(title: "Low CTR", description: "Bad", industry: industry, clicks: 1)
    5.times { JobView.create!(job: job, created_at: 5.days.ago) } # Old views
    job
  end

  subject { described_class.new(low_ctr_job) }

  describe "#anomalies" do
    it "show both low_views and ctr_anomaly" do
      anomalies = subject.anomalies
      expect(anomalies.map { |a| a[:type] }).to contain_exactly("low_views", "ctr_anomaly")
    end
  end
end