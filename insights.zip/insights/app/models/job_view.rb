class JobView < ApplicationRecord
  belongs_to :job
end
