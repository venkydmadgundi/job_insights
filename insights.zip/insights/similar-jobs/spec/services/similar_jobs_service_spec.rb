require 'rails_helper'

describe SimilarJobsService do
  let(:industry) { Industry.find_or_create_by!(name: "Finance") }
  let!(:tag1) { Tag.find_or_create_by!(name: "Remote") }
  let!(:tag2) { Tag.find_or_create_by!(name: "Full-time") }

  let!(:main_job) do
    job = Job.create!(title: "Finance Analyst", description: "Analyze data", industry: industry)
    job.tags << [tag1, tag2]
    job
  end

  let!(:similar_job) do
    job = Job.create!(title: "Senior Finance Analyst", description: "Deep finance work", industry: industry)
    job.tags << [tag1]
    job
  end

  it "returns similar job based on title and tags" do
    result = SimilarJobsService.new(main_job, title: true, tags: true, industry: true).find_similar(limit: 5)
    expect(result).to include(similar_job)
  end
end