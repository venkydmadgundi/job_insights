require 'rails_helper'

describe "SimilarJobs API", type: :request do
  let(:industry) { Industry.find_or_create_by!(name: "Information Technology") }
  let!(:job1) { Job.create!(title: "Junior Dev", description: "Writes code", industry: industry) }
  let!(:job2) { Job.create!(title: "Senior Dev", description: "Reviews code", industry: industry) }

  it "returns similar jobs" do
    get "/api/v1/jobs/#{job1.id}/similar?title=true&tags=false&industry=true"
    expect(response).to have_http_status(:ok)
    expect(JSON.parse(response.body).map { |j| j["id"] }).to include(job2.id)
  end
end